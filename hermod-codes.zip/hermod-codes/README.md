# hermod-system
Bifröst -> UI Module \n
Polaris -> Vehicle Computer \n
Pulse -> RT Computer \n
