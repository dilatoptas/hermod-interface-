#include "serial_communicator.h"
#include <QDebug>
#include <QtEndian> // Küçük/büyük endian dönüşümü için (byte sırası)


SerialCommunicator::SerialCommunicator(QObject *parent) : QObject(parent) {
    serialPort = new QSerialPort(this);
    // Veri geldiğinde veya hata oluştuğunda sinyalleri bağla
    connect(serialPort, &QSerialPort::readyRead, this, &SerialCommunicator::onReadyRead);
    connect(serialPort, &QSerialPort::errorOccurred, this, &SerialCommunicator::handleError);
}

SerialCommunicator::~SerialCommunicator() {
    if(serialPort->isOpen()) serialPort->close();
}

// Portu açar
void SerialCommunicator::openPort(QString portName, int baudRate) {
    serialPort->setPortName(portName);
    serialPort->setBaudRate(baudRate);
    if(!serialPort->open(QIODevice::ReadWrite))
        qDebug() << "Port açılamadı:" << serialPort->errorString();
    else
        qDebug() << "Port açıldı:" << portName;

}

// Portu kapatır
void SerialCommunicator::closePort() {
    if(serialPort->isOpen()) serialPort->close();
}

// Araca veri göndermek için (örneğin manuel kontrol komutları)
void SerialCommunicator::sendData(const QByteArray &data) {
    if(serialPort->isOpen()) serialPort->write(data);
}

// gelen her veri burada parse edilir
// Her veri geldiğinde çağrılır
void SerialCommunicator::onReadyRead() {

     // Gelen veriyi buffer’a ekle
    buffer.append(serialPort->readAll());

    // Frame yapısı: [0xAA][0x55][ID][LEN][DATA][CRC]
    while (buffer.size() >= 6) {
        // HEADER arama
        int startIndex = buffer.indexOf(QByteArray::fromHex("AA55"));
        if (startIndex == -1) {
            buffer.clear();
            return;
        }
        if (startIndex > 0)
            buffer.remove(0, startIndex); // header öncesi gereksiz veriyi at

        if (buffer.size() < 5)
            return; // yeterli veri yok

        quint8 id = static_cast<quint8>(buffer[2]); // Veri tipi ID
        quint8 len = static_cast<quint8>(buffer[3]); // Veri uzunluğu
        int totalFrameSize = 2 + 1 + 1 + len + 1; // AA55 + ID + LEN + DATA + CRC

        if (buffer.size() < totalFrameSize)
            return; // tüm frame henüz gelmemiş

        QByteArray frame = buffer.left(totalFrameSize);
        buffer.remove(0, totalFrameSize);
        parseFrame(frame);
    }
}

// Frame içerisindeki ID’ye göre doğru sinyali gönder
void SerialCommunicator::parseFrame(const QByteArray &frame) {
    quint8 id = static_cast<quint8>(frame[2]);
    quint8 len = static_cast<quint8>(frame[3]);
    QByteArray data = frame.mid(4, len);
    quint8 crc = static_cast<quint8>(frame[4 + len]);

    // CRC kontrolü
    if (calculateCRC(frame.left(4 + len)) != crc) {
        qWarning() << "CRC hatası!";
        return;
    }

    // Gelen ID’ye göre doğru sinyal yayılır
    switch (id) {
    case 0x01: { // Hız
        quint16 raw = qFromLittleEndian<quint16>(reinterpret_cast<const uchar*>(data.constData()));
        emit speedUpdated(raw / 100.0f);
        break;
    }
    case 0x02: { // İvme
        qint16 raw = qFromLittleEndian<qint16>(reinterpret_cast<const uchar*>(data.constData()));
        emit accelUpdated(raw / 100.0f);
        break;
    }
    case 0x03: { // Konum
        float pos;
        memcpy(&pos, data.constData(), sizeof(float));
        emit positionUpdated(pos);
        break;
    }
    case 0x04: { // Voltaj
        quint16 raw = qFromLittleEndian<quint16>(reinterpret_cast<const uchar*>(data.constData()));
        emit voltageUpdated(raw / 100.0f);
        break;
    }
    case 0x05: { // Akım
        qint16 raw = qFromLittleEndian<qint16>(reinterpret_cast<const uchar*>(data.constData()));
        emit currentUpdated(raw / 100.0f);
        break;
    }
    case 0x06: { // Güç
        float pwr;
        memcpy(&pwr, data.constData(), sizeof(float));
        emit powerUpdated(pwr);
        break;
    }
    case 0x07: { // Sıcaklık
        qint16 raw = qFromLittleEndian<qint16>(reinterpret_cast<const uchar*>(data.constData()));
        emit temperatureUpdated(raw / 100.0f);
        break;
    }
    case 0x08: { // Fren
        bool brake = static_cast<bool>(data[0]);
        emit brakeStatusChanged(brake);
        break;
    }
    case 0x09: { // TCP bağlantı durumu
        bool connected = static_cast<bool>(data[0]);
        emit connectionStatusChanged(connected);
        break;
    }
    default:
        qWarning() << "Bilinmeyen ID:" << id;
    }
}

// XOR tabanlı basit CRC doğrulama
quint8 SerialCommunicator::calculateCRC(const QByteArray &data) {
    quint8 crc = 0;
    for (char byte : data)
        crc ^= static_cast<quint8>(byte);
    return crc;
}

void SerialCommunicator::handleError(QSerialPort::SerialPortError error) {
    qDebug() << "Serial Error:" << error;
}
