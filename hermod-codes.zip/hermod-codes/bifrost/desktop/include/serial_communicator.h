#ifndef SERIAL_COMMUNICATOR_H
#define SERIAL_COMMUNICATOR_H


#include <QObject>
#include <QSerialPort>
#include <QByteArray>


// Araçtan gelen veriler binary formatta gelir ve burada çözülür.

class SerialCommunicator : public QObject
{
    Q_OBJECT

public:
    explicit SerialCommunicator(QObject *parent = nullptr);
    ~SerialCommunicator();

    // Seri portu açmak ve kapatmak için QML'den erişilebilir fonksiyonlar
    Q_INVOKABLE void openPort(QString portName, int baudRate = 115200);
    Q_INVOKABLE void closePort();
    Q_INVOKABLE void sendData(const QByteArray &data);


signals:
    // Ham veri (işlenmemiş haliyle)
    void rawDataReceived(const QByteArray &data);

    // Parse sonrası yayınlanan telemetri sinyalleri
    // Bunlar QML tarafında dinlenip ekranda gösterilir
    void speedUpdated(float speed);
    void accelUpdated(float accel);
    void positionUpdated(float position);
    void voltageUpdated(float voltage);
    void currentUpdated(float current);
    void powerUpdated(float power);
    void temperatureUpdated(float temp);
    void brakeStatusChanged(bool engaged);
    void connectionStatusChanged(bool connected);


private slots:
    // Yeni veri geldiğinde tetiklenen Qt slotu
    void onReadyRead();
    // Yeni veri geldiğinde tetiklenen Qt slotu
    void handleError(QSerialPort::SerialPortError error);

private:
    QSerialPort *serialPort;
    QByteArray buffer;
    void parseFrame(const QByteArray &frame);
    quint8 calculateCRC(const QByteArray &data);
};

#endif
