#include "../../include/control/control.h"
#include "../../include/control/communication.h"
#include <stdio.h>
#include "pico/stdlib.h"

int get_message_type_non_sdk(int8_t * data, int size)
{
}
