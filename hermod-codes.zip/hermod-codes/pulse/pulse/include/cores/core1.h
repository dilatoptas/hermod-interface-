#ifndef CORE_1_H
#define CORE_1_H

void core1_entry(); //birinci cekirdek icin cagirma fonksiyonu

#endif
