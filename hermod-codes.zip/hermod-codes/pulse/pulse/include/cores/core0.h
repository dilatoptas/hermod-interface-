#ifndef CORE_0_H
#define CORE_0_H

void core0_entry(); //sifirinci cekirdke dongusu icin baslatma fonksiyonu

#endif
